<?php

namespace App\Controllers;

use App\Models\DeviceModel;

class DevicesController extends BaseController
{
    protected $deviceModel;

    public function __construct()
    {
        $this->devicesModel = new \App\Models\DeviceModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Daftar Barang',
            'device' => $this->deviceModel->getDevice()
        ];

        return view('/pages/devices', $data);
    }
}
