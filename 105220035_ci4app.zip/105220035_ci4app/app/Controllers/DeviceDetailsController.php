<?php

namespace App\Controllers;

use App\Models\DeviceModel;

class DeviceDetailsController extends BaseController
{
    protected $deviceModel;

    public function index($slug)
    {
        $data = [
            'title' => 'Detail Barang',
            'device' => $this->deviceModel->getDevice($slug)
        ];
        return view('/pages/deviceDetails', $data);
    }
}
