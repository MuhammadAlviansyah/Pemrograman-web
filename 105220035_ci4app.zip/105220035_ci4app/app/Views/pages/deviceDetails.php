<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<div class="container">
    <div class="row">
        <div class="col">
            <h2 class="mt-2">Detail Device</h2>
            <div class="card mb-3" style="max-width: 540px;">
                <div class="row no-gutters">
                    <div class="col-md-4">
                        <img src="/img/<?= $device['gambar']; ?>" class="card-img">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h4 class="card-title"><?= $device['device_name']; ?></h4>
                            <p class="card-text"><b>Merk : </b><?= $device['device_brand']; ?></p>
                            <p class="card-text"><small class="text-muted"><b>Quantity : </b><?= $device['device_quantity']; ?></small></p>
                            <a href="/pages/devices" class="btn btn-primary btn-lg">Back to list</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection('content'); ?>