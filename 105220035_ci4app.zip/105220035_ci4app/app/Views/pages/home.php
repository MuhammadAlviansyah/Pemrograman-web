<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<div class="container">
  <div class="row">
    <div class="col">
      <blockquote class="blockquote text-center">
        <br><br><br><br><br><br><br><br><br><br><br>
        <h1 class="display-3">WELCOME, CUSTOMER!</h1>
        <a href="/pages/devices" class="btn btn-primary btn-lg">Get Started</a>
      </blockquote>
      <br>
    </div>
  </div>
</div>

<?= $this->endSection('content'); ?>