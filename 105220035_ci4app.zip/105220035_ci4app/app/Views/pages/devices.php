<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h1 class="mt-2">Daftar Barang</h1>
            <br>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Gambar</th>
                        <th scope="col">Barang</th>
                        <th scope="col">Merk</th>
                        <th scope="col">Jumlah</th>
                        <th scope="col">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($device as $d) : ?>
                        <tr>
                            <th scope="row"><?= $i++; ?></th>
                            <td><img src="/img/<?= $d['gambar']; ?>" alt="" class="foto"></td>
                            <td><?= $d['device_name']; ?></td>
                            <td><?= $d['device_brand']; ?></td>
                            <td><?= $d['device_quantity']; ?></td>
                            <td><?= $d['device_status']; ?></td>
                            <td>
                                <a href="/pages/<?= $d['slug']; ?>" class="btn btn-primary btn-lg">Lihat Detail</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?= $this->endSection('content'); ?>